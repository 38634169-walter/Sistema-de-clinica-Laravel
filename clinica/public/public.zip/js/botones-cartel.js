$(document).ready(botones_cartel);

function botones_cartel(){
    $('.btn-cartel-aviso').click(function(){
        $('.cartel-aviso').css({'display':'none'});
    });
}